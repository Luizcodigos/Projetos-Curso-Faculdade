<?php
include('conexao.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $nome = $_POST['nome'];
  $cpf = $_POST['cpf'];
  $idade = $_POST['idade'];
  $data_consulta = $_POST['data_consulta'];

  $sql = "INSERT INTO usuarios (nome, cpf, idade, data_consulta) 
          VALUES ('$nome', '$cpf', '$idade', '$data_consulta')";

  if ($conn->query($sql) === TRUE) {
    echo "<script>alert('Cadastro realizado com sucesso!'); window.location.href='login.php';</script>";
  } else {
    echo "<script>alert('Erro ao cadastrar. Verifique se o CPF já está cadastrado.');</script>";
  }

  $conn->close();
}
?>
<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <title>Cadastro — Novembro Azul</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: linear-gradient(135deg, #e6f0ff, #ffffff);
      margin: 0;
      padding: 0;
      color: #12233b;
    }
    .container {
      max-width: 500px;
      margin: 60px auto;
      background: #fff;
      padding: 25px;
      border-radius: 10px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    }
    h1 {
      color: #0b4da2;
      text-align: center;
      margin-bottom: 15px;
    }
    label {
      display: block;
      margin-top: 12px;
      font-weight: bold;
    }
    input[type="text"],
    input[type="number"],
    input[type="date"] {
      width: 100%;
      padding: 8px;
      border: 1px solid #ccd7ef;
      border-radius: 6px;
      margin-top: 5px;
      box-sizing: border-box;
    }
    input[type="submit"] {
      background-color: #0b63b7;
      color: #fff;
      border: none;
      border-radius: 6px;
      padding: 10px 16px;
      font-size: 15px;
      margin-top: 20px;
      cursor: pointer;
      width: 100%;
    }
    input[type="submit"]:hover {
      background-color: #094d8d;
    }
    .link {
      text-align: center;
      margin-top: 20px;
      font-size: 14px;
    }
    a {
      color: #0b63b7;
      text-decoration: none;
    }
    a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>Cadastro Novembro Azul</h1>
    <form method="post">
      <label for="nome">Nome</label>
      <input type="text" id="nome" name="nome" required>

      <label for="cpf">CPF</label>
      <input type="text" id="cpf" name="cpf" required maxlength="11" pattern="\d{11}" placeholder="Somente números">

      <label for="idade">Idade</label>
      <input type="number" id="idade" name="idade" required min="1" max="120">

      <label for="data_consulta">Data da Consulta</label>
      <input type="date" id="data_consulta" name="data_consulta" required>

      <input type="submit" value="Cadastrar">
    </form>

    <div class="link">
      <a href="login.php">Já tem cadastro? Acesse as dicas</a>
    </div>
  </div>
</body>
</html>
