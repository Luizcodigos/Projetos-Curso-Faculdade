<?php
include('conexao.php');
$dicas = "";
$nome = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $cpf = $_POST['cpf'];
  $sql = "SELECT * FROM usuarios WHERE cpf='$cpf'";
  $result = $conn->query($sql);

  if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $nome = $row['nome'];

    $dicas = "
      <ul>
        <li>Mantenha uma alimentação equilibrada e rica em frutas, verduras e legumes.</li>
        <li>Pratique atividades físicas regularmente.</li>
        <li>Evite o consumo excessivo de álcool e tabaco.</li>
        <li>Realize exames preventivos regularmente, conforme orientação médica.</li>
        <li>Converse com seu médico sobre seu histórico familiar e fatores de risco.</li>
      </ul>
    ";
  } else {
    echo "<script>alert('CPF não encontrado. Faça o cadastro primeiro.'); window.location.href='index.php';</script>";
    exit;
  }

  $conn->close();
}
?>
<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <title>Acessar Dicas — Novembro Azul</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: linear-gradient(135deg, #e6f0ff, #ffffff);
      margin: 0;
      padding: 0;
      color: #12233b;
    }
    .container {
      max-width: 500px;
      margin: 60px auto;
      background: #fff;
      padding: 25px;
      border-radius: 10px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    }
    h1 {
      color: #0b4da2;
      text-align: center;
      margin-bottom: 15px;
    }
    ul { line-height: 1.8; }
    input[type="text"] {
      width: 100%;
      padding: 8px;
      border: 1px solid #ccd7ef;
      border-radius: 6px;
      margin-top: 5px;
      box-sizing: border-box;
    }
    input[type="submit"] {
      background-color: #0b63b7;
      color: #fff;
      border: none;
      border-radius: 6px;
      padding: 10px 16px;
      font-size: 15px;
      margin-top: 20px;
      cursor: pointer;
      width: 100%;
    }
    input[type="submit"]:hover {
      background-color: #094d8d;
    }
    .link-voltar {
      text-align: center;
      margin-top: 20px;
      font-size: 14px;
    }
    a {
      color: #0b63b7;
      text-decoration: none;
    }
    a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>Acessar Dicas</h1>
    <?php if ($dicas == ""): ?>
      <p>Digite seu CPF para acessar informações sobre prevenção.</p>
      <form method="post">
        <label for="cpf">CPF</label>
        <input type="text" id="cpf" name="cpf" required maxlength="11" pattern="\d{11}" placeholder="Ex: 12345678901">
        <input type="submit" value="Acessar Dicas">
      </form>
    <?php else: ?>
      <h2>Olá, <?php echo $nome; ?>!</h2>
      <p>Veja algumas dicas importantes:</p>
      <?php echo $dicas; ?>
    <?php endif; ?>
    <div class="link-voltar">
      <a href="index.php">← Voltar ao cadastro</a>
    </div>
  </div>
</body>
</html>
