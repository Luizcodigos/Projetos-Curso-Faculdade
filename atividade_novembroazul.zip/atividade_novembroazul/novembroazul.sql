CREATE DATABASE novembroazul;
USE novembroazul;

CREATE TABLE usuarios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(150) NOT NULL,
  cpf VARCHAR(11) NOT NULL UNIQUE,
  idade INT NOT NULL,
  data_consulta DATE NOT NULL
);
